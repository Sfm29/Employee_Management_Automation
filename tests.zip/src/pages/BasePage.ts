import { expect, Locator, Page } from '@playwright/test';

export class BasePage {

    constructor(protected readonly page: Page) {}

    async navigate(url: string): Promise<void> {
        await this.page.goto(url);
    }

    async verifyUrl(url: string): Promise<void> {
        await expect(this.page).toHaveURL(url);
    }

    async verifyTitle(title: string): Promise<void> {
        await expect(this.page).toHaveTitle(title);
    }

    async click(locator: Locator): Promise<void> {
        await locator.click();
    }

    async fill(locator: Locator, value: string): Promise<void> {
        await locator.fill(value);
    }

    async getText(locator: Locator): Promise<string> {
        return (await locator.textContent()) ?? '';
    }

    async waitForPageLoad(): Promise<void> {
        await this.page.waitForLoadState('networkidle');
    }
}