import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { URLS } from '../constants/urls';
import { User } from '../models/User';
import { MESSAGES } from '../constants/messages';

export class LoginPage extends BasePage {

    readonly usernameInput: Locator;
    readonly passwordInput: Locator;
    readonly loginButton: Locator;
    readonly errorMessage: Locator;

    constructor(page: Page) {
        super(page);

        this.usernameInput = page.locator('input[name="username"]');
        this.passwordInput = page.locator('input[name="password"]');
        this.loginButton = page.locator('button[type="submit"]');
        this.errorMessage = page.locator('.oxd-alert-content-text');
    }

    async open(): Promise<void> {
        await this.navigate(URLS.LOGIN);
    }

    async login(user: User): Promise<void> {
        await this.usernameInput.fill(user.username);
        await this.passwordInput.fill(user.password);
        await this.loginButton.click();
    }

    async verifySuccessfulLogin(): Promise<void> {
        await this.verifyUrl(URLS.DASHBOARD);
    }

    async verifyLoginError(): Promise<void> {
        await expect(this.errorMessage).toHaveText(MESSAGES.LOGIN_FAILED);
    }
}