import { User } from '../models/User';

export const adminUser: User = {
    username: 'Admin',
    password: 'admin123'
};